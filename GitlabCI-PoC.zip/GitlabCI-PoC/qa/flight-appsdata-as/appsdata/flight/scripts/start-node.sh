. ./setenv.sh

echo $DATACENTER

umask 0022

JVM_ARGS="-Xms2g -Xmx2g"
#JVM_ARGS="$JVM_ARGS -XX:+UseConcMarkSweepGC -XX:CMSInitiatingOccupancyFraction=75 -XX:+UseCMSInitiatingOccupancyOnly"
#JVM_ARGS="$JVM_ARGS -XX:+PrintGCDetails -Xloggc:../logs/gc-node-$1.log"

JMX_ARGS="-Dcom.sun.management.jmxremote.port=9101 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false"

# Check if parameters have been passed to the script
if [ -z "$1" ]; then
    echo -e "\n\tError: Incorrect Syntax to call script. Please provide number (Starts from 1)\n"
    echo -e "\n\t$0 <NodeNumber>\n"
    exit 2 
  fi

# Check if PID file exists, if it does, dont start process
if [[ -e "../pid/node-$HOSTNAME-$1.pid" ]]; then
   echo -e "\n\tError: PID file ../pid/node-$HOSTNAME-$1.pid exists\n\n\tPlease check if the process is already running and stop it. If it is not running, remove the PID file and retry\n"
   exit 1
  fi 


java -server -showversion -Xms2g -Xmx2g -Diapi.app.id=FES -Diapi.app.name=FlightCache -Diapi.app.type=java -Diapi.logfile.location=/var/log/tibco/flight/iapi-logs -Dlog4j.configuration\=file\:////opt/tibco/appsconfig/flight/config/log4j.xml -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9101 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -cp $CLASSPATH com.tibco.as.space.agent.AgentConsole -discovery $DISCOVERY_URL -listen $LISTEN_URL  -remote_listen $REMOTE_LISTEN_URL -metaspace $METASPACE -name node$1 -data_store $DATASTORE &

echo $! > ../pid/node-$HOSTNAME-$1.pid
