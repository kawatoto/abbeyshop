mkdir -p /opt/tibco/appsdata/flight/logs
mkdir -p /opt/tibco/appsdata/flight/pid
mkdir -p /opt/tibco/appsdata/flight/node-datastores

echo "logs, pid, node-datastores directories created successfully"
