. ./setenv.sh

echo $DATACENTER

umask 0022

JVM_ARGS="-Xms2g -Xmx2g"
#JVM_ARGS="$JVM_ARGS -XX:+UseConcMarkSweepGC -XX:CMSInitiatingOccupancyFraction=75 -XX:+UseCMSInitiatingOccupancyOnly"
#JVM_ARGS="$JVM_ARGS -XX:+PrintGCDetails -Xloggc:../logs/gc-scheduler-$1.log"

JMX_ARGS="-Dcom.sun.management.jmxremote.port=930$1 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false"

# Check if parameters have been passed to the script
if [ -z "$1" ]; then
    echo -e "\n\tError: Incorrect Syntax to call script. Please provide number (Starts from 1)\n"
    echo -e "\n\t$0 <NodeNumber>\n"
    exit 2 
  fi

# Check if PID file exists, if it does, dont start process
if [[ -e "../pid/scheduler-$HOSTNAME-$1.pid" ]]; then
   echo -e "\n\tError: PID file ../pid/scheduler-$HOSTNAME-$1.pid exists\n\n\tPlease check if the process is already running and stop it. If it is not running, remove the PID file and retry\n"
   exit 1
  fi 

echo $CLASSPATH

#nohup java -server -showversion -Dcom.tibco.tibjms.reconnect.attempts=40,10000 -Dcom.tibco.tibjms.connect.attempts=40,10000 -Djb.configLocation=$CONFIG_ROOT/scheduler -Diapi.app.id=FES -Diapi.app.name=FlightScheduler -Diapi.app.type=java -Diapi.logfile.location=/var/log/tibco/flight/iapi-logs -Dlog4j.configuration\=file\:////opt/tibco/appsconfig/flight/config/log4j.xml -cp $CLASSPATH com.jetblue.scheduler.SchedulerAgent > ../logs/scheduler-$HOSTNAME-$1.log 2>&1 &


java -server -showversion -Xms2g -Xmx2g -Dcom.tibco.tibjms.reconnect.attempts=40,10000 -Dcom.tibco.tibjms.connect.attempts=40,10000 -Djb.configLocation=$CONFIG_ROOT/scheduler -Diapi.app.id=FES -Diapi.app.name=FlightScheduler -Diapi.app.type=java -Diapi.logfile.location=/var/log/tibco/flight/iapi-logs -Dlog4j.configuration\=file\:////opt/tibco/appsconfig/flight/config/log4j.xml -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9301 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -cp $CLASSPATH com.jetblue.scheduler.SchedulerAgent &
echo $! > ../pid/scheduler-$HOSTNAME-$1.pid
