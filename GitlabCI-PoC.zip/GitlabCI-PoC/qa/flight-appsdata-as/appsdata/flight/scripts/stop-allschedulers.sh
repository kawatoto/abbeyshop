#
for pidfile in ../pid/scheduler*.pid; do
  if [ -f $pidfile ]; then
    PID=`cat $pidfile`
    echo "Stopping $PID"
    kill $PID && rm $pidfile
  fi
done
