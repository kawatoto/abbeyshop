create bridge source=topic:ENT.FLT.FES.FLTLEG.2 target=queue:APP.FES.ODSLOADER.FLTLEG.RECEIVE.1 selector="EventType='Flight'"
create bridge source=topic:ENT.FLT.FES.FLTLEG.SECURE.2 target=queue:APP.FES.ODSLOADER.FLTLEG.RECEIVE.1 selector="EventSubType='FlightLock'"
create bridge source=topic:ENT.FLT.FES.FLTLEG.2 target=queue:APP.FES.ODSLOADER.FLTLEG.RECEIVE.2 selector="EventType='Flight'"
create bridge source=topic:ENT.FLT.FES.FLTLEG.SECURE.2 target=queue:APP.FES.ODSLOADER.FLTLEG.RECEIVE.2 selector="EventSubType='FlightLock'"
create bridge source=topic:ENT.FLT.FES.FLTLEG.2 target=queue:APP.FES.FLIGHTPUBLISHER.BRIDGE.1
create bridge source=topic:ENT.FLT.FES.FLTLEG.SECURE.2 target=queue:APP.FES.FLIGHTPUBLISHER.BRIDGE.SECURE.1
create bridge source=topic:ENT.FLT.FES.FLTLEG.2 target=queue:APP.FES.FLIGHTPUBLISHER.BRIDGE.2
create bridge source=topic:ENT.FLT.FES.FLTLEG.SECURE.2 target=queue:APP.FES.FLIGHTPUBLISHER.BRIDGE.SECURE.2