show bridge topic ENT.FLT.FES.FLTLEG.2
show bridge topic ENT.FLT.FES.FLTLEG.SECURE.2