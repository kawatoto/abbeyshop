function printUsage(){
	echo -e "\tUsage: ./disable.sh appname"	
	echo -e "\tValid appnames: TibQa01-FPESEventProcessor-Flight-FPESEventProcessorArchive, email"
	exit 2
}

#check if no arguments are specified
if [ -z "$1" ]
  then
    echo -e "\n\tERROR: No arguments supplied"
    printUsage
fi

#!/bin/bash
touch /opt/tibco/appsconfig/flight/monitor/control/$1.disabled
echo "$(date)::Monitoring/Email DISABLED for Application $1" >> /opt/tibco/appsconfig/flight/monitor/control/control.log
