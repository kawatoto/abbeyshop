rm TibQa01-FPESEventProcessor-Flight-FPESEventProcessorArchive.disabled
rm email.disabled
echo "$(date)::Monitoring and Email ENABLED for all applications" >> /opt/tibco/appsconfig/flight/monitor/control/control.log