rm TibQa01-Flight-AdhocLoader-1-FlightAdhocLoaderProcessArchive.disabled
rm TibQa01-BlueEyeMessageTransferManager-BlueEyeMessageTransferManager.disabled
rm TibQa01-Flight-CacheAccessService-Flight-CacheAccessProcessArchive.disabled
rm TibQa01-FlightTracSequencer-1-Flight-FlightTracSequencer-1.disabled
rm TibQa01-Flight-FPMMessageHandler-FPMMessageHandlerProcessArchive.disabled
rm TibQa01-Flight-ODSAccessService-Flight-ODSAccessProcessArchive.disabled
rm TibQa01-Flight-ODSLoader-Flight-ODSLoaderProcessArchive.disabled
rm TibQa01-Flight-ScheduleLoader-Flight-ScheduleLoader.disabled
rm TibQa01-FlightPublisher-FlightPublisherProcessArchive.disabled
rm TibQa01-Flight-TopicRouter-2-Flight-TopicRouterProcessArchive.disabled
rm email.disabled
echo "$(date)::Monitoring ENABLED for all applications" >> /opt/tibco/appsconfig/flight/monitor/control/control.log