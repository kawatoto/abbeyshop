function printUsage(){
	echo -e "\tUsage: ./enable.sh appname"	
	echo -e "\tValid appnames: TibQa01-Flight-FPMMessageHandler-FPMMessageHandlerProcessArchive, TibInt01-BlueEyeMessageTransferManager-BlueEyeMessageTransferManager, 
			TibQa01-FlightPublisher-FlightPublisherProcessArchive, TibInt01-Flight-AdhocLoader-1-FlightAdhocLoaderProcessArchive,
			TibQa01-Flight-CacheAccessService-Flight-CacheAccessProcessArchive, TibInt01-Flight-ODSAccessService-Flight-ODSAccessProcessArchive,
			TibQa01-Flight-ODSLoader-Flight-ODSLoaderProcessArchive, TibInt01-FlightTracSequencer-1-Flight-FlightTracSequencer-1
			TibQa01-Flight-ScheduleLoader-Flight-ScheduleLoader,TibInt01-Flight-TopicRouter-2-Flight-TopicRouterProcessArchive, email"
	exit 2
}

#check if no arguments are specified
if [ -z "$1" ]
  then
    echo -e "\n\tERROR: No arguments supplied"
    printUsage
fi

#!/bin/bash
rm /opt/tibco/appsconfig/flight/monitor/control/$1.disabled
echo "$(date)::Monitoring/Email ENABLED for Application $1" >> /opt/tibco/appsconfig/flight/monitor/control/control.log
