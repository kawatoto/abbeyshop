touch TibQa01-Flight-AdhocLoader-1-FlightAdhocLoaderProcessArchive.disabled
touch TibQa01-BlueEyeMessageTransferManager-BlueEyeMessageTransferManager.disabled
touch TibQa01-Flight-CacheAccessService-Flight-CacheAccessProcessArchive.disabled
touch TibQa01-FlightTracSequencer-1-Flight-FlightTracSequencer-1.disabled
touch TibQa01-Flight-FPMMessageHandler-FPMMessageHandlerProcessArchive.disabled
touch TibQa01-Flight-ODSAccessService-Flight-ODSAccessProcessArchive.disabled
touch TibQa01-Flight-ODSLoader-Flight-ODSLoaderProcessArchive.disabled
touch TibQa01-Flight-ScheduleLoader-Flight-ScheduleLoader.disabled
touch TibQa01-FlightPublisher-FlightPublisherProcessArchive.disabled
touch TibQa01-Flight-TopicRouter-2-Flight-TopicRouterProcessArchive.disabled
touch email.disabled
echo "$(date)::Monitoring DISABLED for all applications" >> /opt/tibco/appsconfig/flight/monitor/control/control.log