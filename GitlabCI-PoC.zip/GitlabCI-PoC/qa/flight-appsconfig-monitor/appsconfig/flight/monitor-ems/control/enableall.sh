rm FlightQueuesMonitoring.disabled
rm FlightTopicsMonitoring.disabled
rm Flight-BizTalkQueueMonitoring.disabled
rm Flight-CacheAccessServicesQueuesMonitoring.disabled
rm Flight-MovementControlQueuesMonitoring.disabled
rm Flight-ODSAccessServicesQueuesMonitoring.disabled
rm Flight-SchedulerQueueMonitoring.disabled
rm email.disabled
echo "$(date)::Monitoring and Email ENABLED for EMS" >> /opt/tibco/appsconfig/flight/monitor/control/control.log