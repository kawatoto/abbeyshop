echo "***�Setting Environment variables for Flight Domain****"

export AS_HOME=/opt/tibco/DSEngine/work/jbecllasi01-0/fabric/as/2.1
export HAWK_HOME=/opt/tibco/hawk/4.9
export RV_HOME=/opt/tibco/tibrv/8.4
export TPL_HOME=/opt/tibco/appsdata/flight/ExternalLibraries
export EMS_HOME=/opt/tibco/appsdata/flight/ExternalLibraries
export DOMAIN=TibInt01
export ENV=int
export PATH=$AS_HOME/lib:$AS_HOME/bin:$TPL_HOME:$PATH
export LD_LIBRARY_PATH=$PATH
export CLASSPATH=$EMS_HOME/lib/*:$AS_HOME/lib/*:$HAWK_HOME/lib/*:$RV_HOME/lib/64/*:$RV_HOME/lib/tibrvj.jar:$TPL_HOME/*
export DISCOVERY_URL="tcp://jbecllasi01.jblab.net:51000"
export LISTEN_URL=tcp://:51000-51100
export REMOTE_LISTEN_URL=tcp://:51200
export JMX_HOST=jbecllbei05.jblab.net
export JMX_PORT=9011
export METASPACE=FlightMS
export DATASTORE=/opt/tibco/appsdata/flight/node-datastores
export OBFUSCATE_INPUT=/opt/tibco/appsconfig/flight/deployables/deployconfig/obfuscate-input.cfg
export EAR_LOCATION=/opt/tibco/appsdeploy/flight/ears
export DEPLOY_CONFIG=/opt/tibco/appsconfig/flight/deployconfig
export CONFIG_ROOT=/opt/tibco/appsconfig/flight/config
