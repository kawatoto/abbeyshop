. ./setenv.sh

java -jar $AS_HOME/lib/as-admin.jar -i FlightMetaspace.txt
exit