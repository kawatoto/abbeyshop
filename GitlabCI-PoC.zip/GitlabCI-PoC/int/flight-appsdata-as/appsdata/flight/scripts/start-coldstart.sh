. ./setenv.sh

echo java -cp "$AS_HOME/lib/*:$TPL_HOME/*" -server -showversion com.jetblue.be.utils.flight.InvokeColdStartMBean $JMX_HOST $JMX_PORT
java -cp "$AS_HOME/lib/*:$TPL_HOME/*" -server -showversion com.jetblue.be.utils.flight.InvokeColdStartMBean $JMX_HOST $JMX_PORT

