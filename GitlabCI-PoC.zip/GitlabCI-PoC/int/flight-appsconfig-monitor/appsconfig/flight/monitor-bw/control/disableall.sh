touch TibInt01-Flight-AdhocLoader-1-FlightAdhocLoaderProcessArchive.disabled
touch TibInt01-BlueEyeMessageTransferManager-BlueEyeMessageTransferManager.disabled
touch TibInt01-Flight-CacheAccessService-Flight-CacheAccessProcessArchive.disabled
touch TibInt01-FlightTracSequencer-1-Flight-FlightTracSequencer-1.disabled
touch TibInt01-Flight-FPMMessageHandler-FPMMessageHandlerProcessArchive.disabled
touch TibInt01-Flight-ODSAccessService-Flight-ODSAccessProcessArchive.disabled
touch TibInt01-Flight-ODSLoader-Flight-ODSLoaderProcessArchive.disabled
touch TibInt01-Flight-ScheduleLoader-Flight-ScheduleLoader.disabled
touch TibInt01-FlightPublisher-FlightPublisherProcessArchive.disabled
touch TibInt01-Flight-TopicRouter-2-Flight-TopicRouterProcessArchive.disabled
touch email.disabled
echo "$(date)::Monitoring DISABLED for all applications" >> /opt/tibco/appsconfig/flight/monitor/control/control.log