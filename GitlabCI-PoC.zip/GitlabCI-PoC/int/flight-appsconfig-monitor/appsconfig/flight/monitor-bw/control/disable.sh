function printUsage(){
	echo -e "\tUsage: ./disable.sh appname"	
	echo -e "\tValid appnames: TibInt01-Flight-FPMMessageHandler-FPMMessageHandlerProcessArchive, TibInt01-BlueEyeMessageTransferManager-BlueEyeMessageTransferManager, 
			TibInt01-FlightPublisher-FlightPublisherProcessArchive, TibInt01-Flight-AdhocLoader-1-FlightAdhocLoaderProcessArchive,
			TibInt01-Flight-CacheAccessService-Flight-CacheAccessProcessArchive, TibInt01-Flight-ODSAccessService-Flight-ODSAccessProcessArchive,
			TibInt01-Flight-ODSLoader-Flight-ODSLoaderProcessArchive, TibInt01-FlightTracSequencer-1-Flight-FlightTracSequencer-1
			TibInt01-Flight-ScheduleLoader-Flight-ScheduleLoader,TibInt01-Flight-TopicRouter-2-Flight-TopicRouterProcessArchive, email"
	exit 2
}

#check if no arguments are specified
if [ -z "$1" ]
  then
    echo -e "\n\tERROR: No arguments supplied"
    printUsage
fi

#!/bin/bash
touch /opt/tibco/appsconfig/flight/monitor/control/$1.disabled
echo "$(date)::Monitoring/Email DISABLED for Application $1" >> /opt/tibco/appsconfig/flight/monitor/control/control.log
