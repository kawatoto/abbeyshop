rm TibInt01-Flight-AdhocLoader-1-FlightAdhocLoaderProcessArchive.disabled
rm TibInt01-BlueEyeMessageTransferManager-BlueEyeMessageTransferManager.disabled
rm TibInt01-Flight-CacheAccessService-Flight-CacheAccessProcessArchive.disabled
rm TibInt01-FlightTracSequencer-1-Flight-FlightTracSequencer-1.disabled
rm TibInt01-Flight-FPMMessageHandler-FPMMessageHandlerProcessArchive.disabled
rm TibInt01-Flight-ODSAccessService-Flight-ODSAccessProcessArchive.disabled
rm TibInt01-Flight-ODSLoader-Flight-ODSLoaderProcessArchive.disabled
rm TibInt01-Flight-ScheduleLoader-Flight-ScheduleLoader.disabled
rm TibInt01-FlightPublisher-FlightPublisherProcessArchive.disabled
rm TibInt01-Flight-TopicRouter-2-Flight-TopicRouterProcessArchive.disabled
rm email.disabled
echo "$(date)::Monitoring ENABLED for all applications" >> /opt/tibco/appsconfig/flight/monitor/control/control.log