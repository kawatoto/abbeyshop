touch TibInt01-FPESEventProcessor-Flight-FPESEventProcessorArchive.disabled
touch email.disabled
echo "$(date)::Monitoring and Email DISABLED for all applications" >> /opt/tibco/appsconfig/flight/monitor/control/control.log