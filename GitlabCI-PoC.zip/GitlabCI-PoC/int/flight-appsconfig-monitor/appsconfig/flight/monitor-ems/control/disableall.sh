touch FlightQueuesMonitoring.disabled
touch FlightTopicsMonitoring.disabled
touch Flight-BizTalkQueueMonitoring.disabled
touch Flight-CacheAccessServicesQueuesMonitoring.disabled
touch Flight-MovementControlQueuesMonitoring.disabled
touch Flight-ODSAccessServicesQueuesMonitoring.disabled
touch Flight-SchedulerQueueMonitoring.disabled
touch email.disabled
echo "$(date)::Monitoring and Email DISABLED for EMS" >> /opt/tibco/appsconfig/flight/monitor/control/control.log