create topic ENT.FLT.FES.FLTLEG.1
create topic ENT.FLT.FES.FLTLEG.SECURE.1
create topic ENT.FLT.FES.FLTLEG.2
create topic ENT.FLT.FES.FLTLEG.SECURE.2