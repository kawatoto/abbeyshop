delete topic ENT.FLT.FES.FLTLEG.1
delete topic ENT.FLT.FES.FLTLEG.SECURE.1
delete topic ENT.FLT.FES.FLTLEG.2
delete topic ENT.FLT.FES.FLTLEG.SECURE.2