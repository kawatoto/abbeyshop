mkdir -p /opt/tibco/appsconfig/flight/config/mappings/flightR2_1_0
mkdir -p /opt/tibco/appsconfig/flight/config/mappings/flightR3
mkdir -p /opt/tibco/appsconfig/flight/mqbindings/BlueEye
mkdir -p /opt/tibco/appsconfig/flight/config/bindings/FPMMessageHandler
mkdir -p /opt/tibco/appsdata/flight/application/data/op-ssim
mkdir -p /opt/tibco/appsdata/flight/application/data/pub-ssim
mkdir -p /opt/tibco/appsdata/flight/application/data/ssm
mkdir -p /opt/tibco/appsdata/flight/application/data/op-ssim-archive
mkdir -p /opt/tibco/appsdata/flight/application/data/pub-ssim-archive
mkdir -p /opt/tibco/appsdata/flight/application/data/ssm-archive

echo "flightR2_1_0, flightR3, BlueEye, FPMMessageHandler, op-ssim, pub-ssim, ssm, op-ssim-archive, pub-ssim-archive, ssm-archive  directories created successfully!"